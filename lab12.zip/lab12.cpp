#include "lab12.h"
void grow(widget*& array, int& size);
void dynamicWidgetManager( string input, string output )
{
    ifstream in;
    in.open(input);
    ofstream out;
    out.open(output);
    int subcommand;          
    int numline=0,size=10;
    widget* data_array = new widget[size];
    while(!in.fail())
    {
        string filename,command;
        in >> command;
        if(command =="load")
        {
            in >> filename;
            ifstream load;
            load.open(filename);
            string lines;
            while (getline(load, lines))
            {
                numline++;
                if (numline == size)
                {
                    grow(data_array, size);
                }
            }
            load.close();
            ifstream loadagain;
            loadagain.open(filename);
            while(!loadagain.fail())
            {
                for(int i=0;i<numline;i++)
                {
                    loadagain >>data_array[i].name;
                    
                    loadagain >> data_array[i].quantity;
                    loadagain >> data_array[i].cost;
                }
            }
            out << "Command: "<<command<<" " << filename<<endl;
            out << "\tLoaded: " <<numline<<endl; 
        }
        else if(command=="showMeTheWidget")
        {
            in >> subcommand;
            out << "Command: "<<command<<" "<< subcommand<<endl;
            if (subcommand<=numline&&subcommand>=0) 
            {
                out << "\tName: " << data_array[subcommand].name << endl;
                cout << data_array[subcommand].name << endl;
                out << "\tQuantity: " << data_array[subcommand].quantity << endl;
                out << "\tCost: $" << data_array[subcommand].cost << endl;
            }
            else
            {
                out<<"\tSorry, bad widget number "<< subcommand <<endl;
            }
        }
    }
    out.close();
    delete[] data_array;
}

void grow(widget*& array, int& size) 
{
    widget* temp = array;//get a copy of the pointer
    array = new widget[size*2];//make a new larger array
    for( int i=0; i<size; i++ )
        array[i] = temp[i]; //copy from the full array into the new array
    delete [] temp; //delete the old array via temp
    size =size*2;//double the size the as: size = size *2;
    temp = nullptr;
}