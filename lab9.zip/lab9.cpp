#include "lab9.h"



void read2D_Data(string input, string output)
{
	
	ifstream fin;
	fin.open(input);
	ofstream fout(output);
	char array[13][2];
	int num1=-1, num2=-1;
	while (!fin.fail())
	{
		string command, loadfile;
		
		fin >> command;
		if (command == "load")
		{
			fin >> loadfile;
			ifstream infile;
			infile.open(loadfile);
			for (int i = 0; i < 13; i++)
			{
				for (int j = 0; j < 2; j++)
				{
					infile >> array[i][j];
					//cout << array[i][j] << "(" << i << "," << j << ")" << endl;
				}
			}
			infile.close();
		}
		else if (command == "location")
		{
			fin >> num1;
			fin.ignore();
			fin >> num2;
			fin.ignore();
			if (num1 < 13 && num1>=0 && num2>=0 && num2 < 2) 
			{
				/*cout << num1 << "," << num2 <<":"<<array[num1][num2] << endl;*/
				fout << num1 << "," << num2 << ":" << array[num1][num2] << endl;
			}
			else
			{
				fout << num1 << "," << num2 << ": bad location" << endl;
			}
			
		}
	}
	fout.close();
}



