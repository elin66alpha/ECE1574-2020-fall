#include <string>
#include <fstream>
#include <istream>
#include <iostream>


using namespace std;


void read2D_Data(string input, string output);