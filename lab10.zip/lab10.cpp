#include "lab10.h"



void arrayStruct(string input, string output)
{
	ifstream fin;
	fin.open(input);
	ofstream fout(output);
	give_array astruct;
	int num = 0;	astruct.size = 0;
	while (!fin.fail())
	{
		string command, loadfile;
		
		fin >> command;
		if (command == "file")
		{
			fin >> loadfile;
			ifstream infile;
			infile.open(loadfile);
			//string a;
			//while (!infile.fail())
			//	++astruct.size;
			
			while (!infile.eof()&&astruct.size<10)
			{
				infile >> astruct.array[astruct.size];	cout << astruct.array[astruct.size]<<endl;
				if (astruct.array[astruct.size] != "")
					astruct.size=astruct.size +1;
			}
			
			fout << "Command file " << loadfile << endl;
			fout << "Loaded " << astruct.size << endl;
			
			infile.close();
		}
		else if (command == "show")
		{
			fin >> num;
			
			if (astruct.array[num]!=""&&num>=0&&num<10)
			{
				fout <<"Command show " <<num << " " <<  astruct.array[num] << endl;
			}
			else 
			{
				fout << "Command show " << num << " bad location" << endl;
			}
			
		}
		
	}
	fout.close();
}



