#include <string>
#include <fstream>
#include <istream>
#include <iostream>

using namespace std;
#define ARR_SIZE   10

struct give_array
{
    int size=0;
    string array[ARR_SIZE];
};
void arrayStruct(string input, string output);