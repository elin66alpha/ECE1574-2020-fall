#include "lab5.h"
using std::stod;
void mathCalculator() 
{
	string command, str,strnum;
	double argument1, argument2, answer;
	getline(cin, str);
	cout << "Command         Argument1  [Argument2]    Answer" << endl;
	while (!cin.fail())
	{
		int index = 0;
		int index2 = 0;
		index = str.find(" ",0);
		command = str.substr(0, index);
		strnum = str.substr(index + 1, str.length());
		index2 = strnum.find(" ", 0);
		
		if (index == -1) {
			argument1 = stod(strnum);
		}
		else {
			argument1 = stod(strnum.substr(0, index2));
			argument2 = stod(strnum.substr(index2+1,strnum.length()));
		}

		if (command.compare("exponential") == 0) {
			answer = exp(argument1);
			cout << command << " " << argument1 << " " << answer << endl;
		}
		else if (command.compare("natural-log") == 0) {
			answer = log(argument1);
			cout << command << " " << argument1 << " " << answer << endl;
		}
		else if (command.compare("log") == 0) {
			answer = log10(argument1);
			cout << command << " " << argument1 << " " << answer << endl;
		}
		else if (command.compare("raised-to-the-power") == 0) {
			answer = pow(argument1, argument2);
			cout << command << " " << argument1 << " " << argument2 << " " << answer << endl;
		}
		else if (command.compare("square-root") == 0) {
			answer = sqrt(argument1);
			cout << command << " " << argument1 << " " << answer << endl;
		}
		else if (command.compare("ceiling") == 0) {
			answer = ceil(argument1);
			cout << command << " " << argument1 << " " << answer << endl;
		}
		else if (command.compare("floor") == 0) {
			answer = floor(argument1);
			cout << command << " " << argument1 << " " << answer << endl;
		}
		else {
			cout << "Unknown command: " << command <<endl;
		}
		getline(cin, str);
	}
}