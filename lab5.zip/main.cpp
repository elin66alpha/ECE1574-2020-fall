#include "lab5.h"
int main()
{
	mathCalculator();
}