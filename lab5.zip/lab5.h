
#define _USE_MATH_DEFINES //this let's VS use the math constants in cmath//libraries we'll be using
#include <string>
#include <fstream>
#include <cmath>
#include <iostream>//The parts from those libraries we want to use
using std::cin;
using std::cout;
using std::string;
using std::string;
using std::stod;
using std::endl;/* Here's the function declaration again.  It  * let's my test code be able to compile against and  * call your function. */ 
void mathCalculator();

