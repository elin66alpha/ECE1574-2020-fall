#include "lab8.h"


void arrayChecking(string input, string output)
{
	
	ifstream file;
	file.open(input);
	ofstream fout(output);
	fout << "Index \t" << "Letter " << endl;
	string inpu;
	char array[30];
	for (int i = 0; i < 30; i++) array[i] = ' ';


	while (!file.fail()) 
	{	
		int num;
		char letter;
		file >> num;
		file.ignore();
		file >> letter;
			if (num<=29&&num>=0)
			{
				array[num] = letter;
			}
			
	}		
			
		for (int i=0; i < 30; i++)
		{
			fout << i << "\t" << array[i] << endl;
			cout << array[i] << endl;
		}
	
	fout.close();
}



