#include <string>
#include <fstream>
#include <istream>
#include <iostream>


using namespace std;



void arrayChecking(string input, string output);