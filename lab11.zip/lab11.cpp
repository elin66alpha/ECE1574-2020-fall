#include "lab11.h"
widget widget_array[10];
void widgetManager( string input, string output )
{
    ifstream fin; //introduce the variable
    fin.open(input);
    ofstream fout;
    fout.open(output);
    int suborder;          
    int count=0;
    while(!fin.fail())
    {
        string number,second;//string counts
        fin >> second;
        if(second=="load")
        {
            fin >> number;
            ifstream load1;//define variable
            load1.open(number);
            string counts;
            while(getline(load1,counts))//set up loop
            {
                count++;
            }
            load1.close();
            ifstream load2;
            load2.open(number);
            while(!load2.fail())
            {
                for(int i=0;i<count;i++)
                {
                    load2 >>widget_array[i].name;
                    load2 >> widget_array[i].quantity;
                    load2 >> widget_array[i].cost;
                }
            }
            fout << "Command: load " << number<<endl;
            fout << "\tLoaded: " <<count<<endl; 

        }
        else if(second=="showMeTheWidget")//continue the loop
        {
            fin >> suborder;
            fout << "Command: showMeTheWidget "<< suborder<<endl;
            if (suborder>=count||suborder<0) 
            {
                fout<<"\tSorry, bad widget number "<< suborder<<endl;
            }
            else
            {
                fout <<"\tName: " << widget_array[suborder].name<<endl;
                fout << "\tQuantity: " << widget_array[suborder].quantity<<endl;
                fout << "\tCost: $" << widget_array[suborder].cost<<endl;
            }
        }
    }
    fout.close();
}