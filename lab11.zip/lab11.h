#include <iostream>
#include<istream>
#include<fstream>
#include<string>
using namespace std;
struct widget
{
    string name;
    int quantity;
    double cost;
};

void widgetManager( string input, string output );