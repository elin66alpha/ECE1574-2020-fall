#include<iostream>
#include<string>
#include<fstream>

using std::string;
using std::ifstream;
using std ::ofstream;
using std::endl;
using std::istream;
using std::ostream;
using std::cout;

void flags(string input, string output);
bool readData(istream& in, string& name, int& landmass, int& zone, int& area, int& pop, int& lang,
	int& reli, int& bars, int& stripes, int& colnum, int& red, int& green, int& blue, int& gold, int& white, int& black,
	int& orange, string& mainhue, int& circles, int& upcross, int& dicross, int& quat, int& sunstars, int& crescent, 
	int& trian, int& icon, int& anime, int& text, string& topleft, string& botright
	);
void country_color(string file, string country, ostream& out); 
void country_name(string file, string country, ostream& out);
void country_landmass(string file, string country, ostream& out);
void displayData(ostream& out, string name, int landmass, int zone, int area, int pop, int lang,
	int reli, int bars, int stripes, int colnum, int red, int green, int blue, int gold, int white, int black,
	int orange, string mainhue, int circles, int upcross, int dicross, int quat, int sunstars, int crescent,
	int trian, int icon, int anime, int text, string topleft, string botright
	);

