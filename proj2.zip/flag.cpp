
//ȱ����ɫ����ָ�
//ȱ�ٹ��ҵ��ܼ�
//ȱ�ٹ��ҵ�����


#include "flag.h"
#include <string>
#include<iostream>
using std::istream;
using std::ofstream;
bool readData(istream& in, string& name, int& landmass, int& zone, int& area, int& pop, int& lang,
	int& reli, int& bars, int& stripes, int& colnum, int& red, int& green, int& blue, int& gold, int& white, int& black,
	int& orange, string& mainhue, int& circles, int& upcross, int& dicross, int& quat, int& sunstars, int& crescent,
	int& trian, int& icon, int& anime, int& text, string& topleft, string& botright)
{
	
	if(!in.fail())
	{
		getline(in, name,',');
		in >> landmass;in.ignore();
		in >> zone;in.ignore();
		in >> area;in.ignore();
		in >> pop;in.ignore();
		in >> lang;in.ignore();
		in >> reli;in.ignore();
		in >> bars;in.ignore();
		in >> stripes;in.ignore();
		in >> colnum;in.ignore();
		in >> red;in.ignore();
		in >> green;in.ignore();
		in >> blue;in.ignore();
		in >> gold;in.ignore();
		in >> white;in.ignore();
		in >> black;in.ignore();
		in >> orange;in.ignore();
		getline(in, mainhue,',');
		in >> circles;in.ignore();
		in >> upcross;in.ignore();
		in >> dicross;in.ignore();
		in >> quat;in.ignore();
		in >> sunstars;in.ignore();
		in >> crescent;in.ignore();
		in >> trian;in.ignore();
		in >> icon;in.ignore();
		in >> anime;in.ignore();
		in >> text;in.ignore();
		getline(in, topleft,',');
		getline(in, botright);
	}
		return in.fail();
}

void country_name(string file, string country, ostream& out)
{
	ifstream in(file);
	if (!in.is_open())
	{
		cout << "\n Error: Unable to open the file! ";
		exit(0);
	}
	string name;int landmass; int zone; int area; int pop; int lang;int reli; int bars; int stripes; int colnum; int red; 
	int green; int blue; int gold; int white;int black;int orange; string mainhue; int circles; int upcross; int dicross;
	int quat; int sunstars; int crescent;int trian; int icon; int anime; int text; string topleft; string botright;
	bool found = false; int i = 0;

	while (!readData(in, name, landmass, zone, area, pop, lang,
		reli, bars, stripes, colnum, red, green, blue, gold, white, black,
		orange, mainhue, circles, upcross, dicross, quat, sunstars, crescent,
		trian, icon, anime, text, topleft, botright))
	{
		
		if (name.find(country)!= std::string::npos)
			{
				displayData(out, name, landmass, zone, area, pop, lang,
					reli, bars, stripes, colnum, red, green, blue, gold, white, black,
					orange, mainhue, circles, upcross, dicross, quat, sunstars, crescent,
					trian, icon, anime, text, topleft, botright);
				found = true;
				i++;
			}	
	}
	if (!found)
		out << "Sorry no flags with part of its name " << country << " found." << endl;
	else
		out << "Total flags found:  " << i << endl;
}

void country_color(string file, string country, ostream& out)
{
	ifstream in(file);
	string name; int landmass; int zone; int area; int pop; int lang; int reli; int bars; int stripes; int colnum; int red;
	int green; int blue; int gold; int white; int black; int orange; string mainhue; int circles; int upcross; int dicross;
	int quat; int sunstars; int crescent; int trian; int icon; int anime; int text; string topleft; string botright;
	bool found = false; string color1, color2,color3,color4,null; int i = 0; int colornum = 0; string realcolor;
	int index = 0; int index2 = 0; int index3 = 0;
	country = country.substr(1, country.length());
	index = country.find(" ", 0);
	if (index != -1)
	{
		color1 = country.substr(0, index);
		string substr1;
		substr1 = country.substr(index + 1, country.length());
		index2 = substr1.find(" ", 0);
		if (index2 != -1)
		{
			string substr2;
			color2 = substr1.substr(0, index2);
			substr2 = substr1.substr(index2 + 1, substr1.length());
			index3 = substr2.find(" ", 0);
			if (index3 != -1)
			{
				color3 = substr2.substr(0, index3);
				color4 = substr2.substr(index3 + 1, substr2.length());
			}
			else
			{
				color3 = substr2;
				color4 = "";
			}
				
		}
		else
		{
			color2=substr1;
			color3 = "";
			color3 = "";
		}
			
	}
	else
	{
		color1 = country;
		color2 = "";
		color3 = "";
		color4 = "";
	}
		
	
	
	const int red_mask = 1000000;
	const int green_mask = 100000;
	const int blue_mask = 10000;
	const int gold_mask = 1000;
	const int white_mask = 100;
	const int black_mask = 10;
	const int orange_mask = 1;
	if (color1 != "") 
	{
		if (color1 == "red") colornum = colornum + red_mask;
		else if (color1 == "green") colornum = colornum + green_mask;
		else if (color1 == "blue") colornum = colornum + blue_mask;
		else if (color1 == "gold") colornum = colornum + gold_mask;
		else if (color1 == "white") colornum = colornum + white_mask;
		else if (color1 == "black") colornum = colornum + black_mask;
		else if (color1 == "orange") colornum = colornum + orange_mask;
	}
	
	if (color2 != "")
	{
		if (color2 == "red") colornum = colornum + red_mask;
		else if (color2 == "green") colornum = colornum + green_mask;
		else if (color2 == "blue") colornum = colornum + blue_mask;
		else if (color2 == "gold") colornum = colornum + gold_mask;
		else if (color2 == "white") colornum = colornum + white_mask;
		else if (color2 == "black") colornum = colornum + black_mask;
		else if (color2 == "orange") colornum = colornum + orange_mask;
	}
	
	if (color3 != "")
	{
		if (color3 == "red") colornum = colornum + red_mask;
		else if (color3 == "green") colornum = colornum + green_mask;
		else if (color3 == "blue") colornum = colornum + blue_mask;
		else if (color3 == "gold") colornum = colornum + gold_mask;
		else if (color3 == "white") colornum = colornum + white_mask;
		else if (color3 == "black") colornum = colornum + black_mask;
		else if (color3 == "orange") colornum = colornum + orange_mask;
	}
	if (color4 != "")
	{
		if (color4 == "red") colornum = colornum + red_mask;
		else if (color4 == "green") colornum = colornum + green_mask;
		else if (color4 == "blue") colornum = colornum + blue_mask;
		else if (color4 == "gold") colornum = colornum + gold_mask;
		else if (color4 == "white") colornum = colornum + white_mask;
		else if (color4 == "black") colornum = colornum + black_mask;
		else if (color4 == "orange") colornum = colornum + orange_mask;
	}
	
	while (!readData(in, name, landmass, zone, area, pop, lang,
		reli, bars, stripes, colnum, red, green, blue, gold, white, black,
		orange, mainhue, circles, upcross, dicross, quat, sunstars, crescent,
		trian, icon, anime, text, topleft, botright))
	{
		int realcolornum = 0;
		realcolor.append(std::to_string(red));
		realcolor.append(std::to_string(green));
		realcolor.append(std::to_string(blue));
		realcolor.append(std::to_string(gold));
		realcolor.append(std::to_string(white));
		realcolor.append(std::to_string(black));
		realcolor.append(std::to_string(orange));
		
		realcolornum = stoi(realcolor);
		

		if(colornum==realcolornum)
		{
				displayData(out, name, landmass, zone, area, pop, lang,
					reli, bars, stripes, colnum, red, green, blue, gold, white, black,
					orange, mainhue, circles, upcross, dicross, quat, sunstars, crescent,
					trian, icon, anime, text, topleft, botright);
				found = true;
				i++;
				
		}
		realcolor = "";
		realcolornum = 0;
	}
	if (!found)
		out << "Sorry no flags with just  " <<country << " found." << endl;
	else
		out << "Total flags found:  " << i << endl;
}
void country_landmass(string file, string country, ostream& out)
{
	
	ifstream in(file);
	string name; int landmass; int zone; int area; int pop; int lang; int reli; int bars; int stripes; int colnum; int red;
	int green; int blue; int gold; int white; int black; int orange; string mainhue; int circles; int upcross; int dicross;
	int quat; int sunstars; int crescent; int trian; int icon; int anime; int text; string topleft; string botright;
	bool found = false;
	int landnum = 0; int i=0;
	if (country == "N.America") landnum = 1;
	else if (country == "S.America") landnum = 2;
	else if (country == "Europe") landnum = 3;
	else if (country == "Africa") landnum = 4;
	else if (country == "Asia") landnum = 5;
	else if (country == "Oceania") landnum = 6;
	else landnum = 0;
	while (!readData(in, name, landmass, zone, area, pop, lang,
		reli, bars, stripes, colnum, red, green, blue, gold, white, black,
		orange, mainhue, circles, upcross, dicross, quat, sunstars, crescent,
		trian, icon, anime, text, topleft, botright))
	{
		
		if (landnum == landmass)
		{
			displayData(out, name, landmass, zone, area, pop, lang,
				reli, bars, stripes, colnum, red, green, blue, gold, white, black,
				orange, mainhue, circles, upcross, dicross, quat, sunstars, crescent,
				trian, icon, anime, text, topleft, botright);
			found = true;
			i++;
		}
	}
	if (!found)
		out << "Sorry no flags in area " << country << " found." << endl;
	else
		out << "Total flags found:  " << i  << endl;
}


void displayData(ostream& out, string name, int landmass, int zone, int area, int pop, int lang,
	int reli, int bars, int stripes, int colnum, int red, int green, int blue, int gold, int white, int black,
	int orange, string mainhue, int circles, int upcross, int dicross, int quat, int sunstars, int crescent,
	int trian, int icon, int anime, int text, string topleft, string botright)
{	
	string s;
	ifstream fin("flags.csv");
	int RowCount = 1;


	while (!fin.eof()) {
		getline(fin, s);
		if (s.find(name) == 0)
		{
			break;
		}
		RowCount++;
	}

	fin.close();
	
	string la;
	if (landmass == 1)la = "N.America";
	else if (landmass == 2)la = "S.America";
	else if (landmass == 3)la = "Europe";
	else if (landmass == 4)la = "Africa";
	else if (landmass == 5)la = "Asia";
	else if (landmass == 6)la = "Oceania";
	string z;
	if (zone == 1)z = "NE";
	else if (zone == 2)z = "SE";
	else if (zone == 3)z = "SW";
	else if (zone == 4)z = "NW";
	string language=" ";
	if (lang == 1)language = "English";
	else if (lang == 2)language = "Spanish";
	else if (lang == 3)language = "French";
	else if (lang == 4)language = "German";
	else if (lang == 5)language = "Slavic";
	else if (lang == 6)language = "Other Indo-European";
	else if (lang == 7)language = "Chinese";
	else if (lang == 8)language = "Arabic";
	else if (lang == 9)language = "Japanese/Turkish/Finnish/Magyar";
	else if (lang == 10)language = "Other";
	string religion=" ";
	if (reli == 0)religion = "Catholic";
	else if (reli == 1)religion = "Other Christian";
	else if (reli == 2)religion = "Muslim";
	else if (reli == 3)religion = "Buddhist";
	else if (reli == 4)religion = "Hindu";
	else if (reli == 5) religion = "Ethnic";
	else if (reli == 6)religion = "Marxist";
	else if (reli == 7) religion = "Other";
	string colors=" ";
	if (red == 1) colors.append("\tRed");
	if (green == 1) colors.append("\tGreen");
	if (blue == 1) colors.append("\tBlue");
	if (gold == 1) colors.append("\tYellow");
	if (white == 1) colors.append("\tWhite");
	if (black== 1) colors.append("\tBlack");
	if (orange == 1) colors.append("\tOrange");
	string shapes=" ";
	if (circles > 0) shapes.append("\tCircles");
	if (upcross > 0) shapes.append("\tCrosses");
	if (dicross >0) shapes.append("\tSaltires");
	if (quat >0) shapes.append("\tQuarters");
	if (sunstars >0) shapes.append("\tSunstars");
	if (crescent == 1) shapes.append("\tCrescent");
	if (trian == 1) shapes.append("\tTriangle");
	if (icon == 1) shapes.append("\tIcon");
	if (anime == 1) shapes.append("\tAnimate");
	if (text == 1) shapes.append("\tText");
	
	out << "Flag: " << RowCount << endl;
	out << name << "\t" << la << "\t" << z << "\t" << area << "\t1000KM^2\t" << pop << "Mil\t" << language << "\t" << religion << "\t" << endl;
	out << "Bars: " << bars << " Stripes: " << stripes << " Colors: " << colnum << colors << " Main hue: " << mainhue << endl;
	out << "Shapes: " << shapes << endl;
	out << "Top left: " << topleft << " Bottom Right: " << botright << endl;
}


void flags(string input, string output)
{
	ifstream in(input);
	ofstream out;
	out.open(output);
	
	while (!in.fail())
	{
		string command;
		in >> command;
		
		if (command == "colors")
		{
			string subcommand;
			getline(in, subcommand);
			out << "Command: colors " << subcommand << endl;
			country_color("flags.csv", subcommand,out);
		}
		 if (command == "name")
		{
			string subcommand;
			in>> subcommand;
			out << "Command: name " << subcommand << endl;
			country_name("flags.csv", subcommand,out);
		}
		else if (command == "landmass")
		{
			string subcommand;
			in >> subcommand;
			out << "Command: landmass " << subcommand << endl;
			country_landmass("flags.csv", subcommand,out);
		}
	}
	out.close();
}



