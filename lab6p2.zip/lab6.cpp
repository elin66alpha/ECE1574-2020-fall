#include <iostream>
#include <sstream>
#include <cmath>
#include<string>
#include <fstream> // For ifstream
#include <stdlib.h> // For function exit()
#include "lab6.h"
using namespace std;

// Function to return sum of the squares of the given parameters
double sumOfSquares(double d1, double d2, double d3, double d4)
{
	double sum;
	// Calculates the sum of the square of the given parameters
	sum = (d1 * d1) + (d2 * d2) + (d3 * d3) + (d4 * d4);
	// Return sum
	return sum;
}// End of function

// Function to return mean of the given parameters
double mean(int x1, int x2, int x3, int x4)
{
	double mean, sum = 0.0;
	// Calculates the sum
	sum = x1 + x2 + x3 + x4;
	// Calculates mean
	mean = sum / 4;
	// Return mean
	return mean;
}// End of function

// Function to return variance of the given parameters
double variance(int x1, int x2, int x3, int x4)
{
	// Calls the function to calculate mean
	double me = mean(x1, x2, x3, x4);
	double temp = 0;
	// Calls the function to calculate sum of the square of number minus mean
	temp += sumOfSquares((x1 - me), (x2 - me), (x3 - me), (x4 - me));
	// Return variance
	return temp / 4;
}// End of function

// Function to return standard deviation of the given parameters
double stdDev(int x1, int x2, int x3, int x4)
{
	// Calls the function to calculate variance and return standard deviation
	return sqrt(variance(x1, x2, x3, x4));
}// End of function

void standardDeviation(string input, string output)
{
	// To store numbers read from file
	int x1, x2, x3, x4;
	// To store the string command read from file

	// File stream object declared
	ifstream fRead;

	// Open the file Command.txt for reading
	fRead.open(input);

	// Check that file can be opened or not
	// is_open() function returns true if a file is open and associated with this stream object.
	// Otherwise returns false.
	if (!fRead.is_open())
	{
		// Displays error message
		cout << "\n Error: Unable to open the file! Command.txt";
		// Exit the program
		exit(0);
	}// End of if condition
	ofstream fout;
	fout.open(output);
	// Loops till not end of the file
	// eof() function returns true if the stream's eofbit error state flag is set (which signals that the End-of-File has been reached
	// by the last input operation). Otherwise returns false.
	while (!fRead.eof())
	{

		// Initializes input command to null for each command read from file
		input = "";
		// Read the command name from file
		fRead >> input;
		// Read the numbers from the file
		fRead >> x1;
		fRead >> x2;
		fRead >> x3;
		fRead >> x4;
		// stream used for the conversion
		std::ostringstream convert1;
		// Insert the textual representation of 'x1' in the characters in the stream
		convert1 << x1;
		// Set 'result1' to the contents of the stream
		string result1 = convert1.str();

		// stream used for the conversion
		std::ostringstream convert2;
		// Insert the textual representation of 'x2' in the characters in the stream
		convert2 << x2;
		// Set 'result12' to the contents of the stream
		string result2 = convert2.str();

		// stream used for the conversion
		std::ostringstream convert3;
		// Insert the textual representation of 'x3' in the characters in the stream
		convert3 << x3;
		// Set 'result13' to the contents of the stream
		string result3 = convert3.str();

		// stream used for the conversion
		std::ostringstream convert4;
		// Insert the textual representation of 'x4' in the characters in the stream
		convert4 << x4;
		// Set 'result14' to the contents of the stream
		string result4 = convert4.str();



		// Displays the command and the numbers

		// Checks the command for mean
		if (input.compare("mean") == 0) {

			cout << "Command: " << input << " " << x1 << " " << x2 << " " << x3 << " " << x4 << endl;
			fout << "Command: " << input << " " << x1 << " " << x2 << " " << x3 << " " << x4 << endl;
			// Calls the function mean and displays the value
			cout << "\tMean: " << mean(x1, x2, x3, x4) << endl;
			fout << "\tMean: " << mean(x1, x2, x3, x4) << endl;

		}
		// Otherwise, checks the command for sum of squares
		else if (input.compare("sum-of-squares") == 0) {

			cout << "Command: " << input << " " << x1 << " " << x2 << " " << x3 << " " << x4 << endl;
			fout << "Command: " << input << " " << x1 << " " << x2 << " " << x3 << " " << x4 << endl;
			// Calls the function sumOfSquare and displays the value
			cout << "\tSum of Squares: " << sumOfSquares(x1, x2, x3, x4) << endl;
			fout << "\tSum of Squares: " << sumOfSquares(x1, x2, x3, x4) << endl;

		}
		// Otherwise, checks the command for variance
		else if (input.compare("variance") == 0) {

			cout << "Command: " << input << " " << x1 << " " << x2 << " " << x3 << " " << x4 << endl;
			fout << "Command: " << input << " " << x1 << " " << x2 << " " << x3 << " " << x4 << endl;
			// Calls the function variance and displays the value
			cout << "\tVariance: " << variance(x1, x2, x3, x4) << endl;
			fout << "\tVariance: " << variance(x1, x2, x3, x4) << endl;

		}
		// Otherwise, checks the command for standard deviation
		else if (input.compare("standard-deviation") == 0) {

			cout << "Command: " << input << " " << x1 << " " << x2 << " " << x3 << " " << x4 << endl;
			fout << "Command: " << input << " " << x1 << " " << x2 << " " << x3 << " " << x4 << endl;
			// Calls the function stdDev and displays the value
			cout << "\tStandard Deviation: " << stdDev(x1, x2, x3, x4) << endl;
			fout << "\tStandard Deviation: " << stdDev(x1, x2, x3, x4) << endl;

		}

	}// End of while loop
	fout.close();
}// End of main function