
#ifndef LAB6_H
#define LAB6_H
// Prototype of functions
#include <string>
using std::string;
void standardDeviation(string input, string output); //declaration of standardDeviation function
double stdDev(int x1, int x2, int x3, int x4);
double mean(int x1, int x2, int x3, int x4);
double variance(int x1, int x2, int x3, int x4);
double sumOfSquares(double d1, double d2, double d3, double d4);
#endif // LAB6_H