#include "Recipe.h"
using std::cout;
using std::endl;
Recipe::Recipe()
{
    size=10;//this is the amount or capacity my list can hold
    count=0;//this is how many ingredients are currently in my list
    list=new Ingredient[size];//this is the list, or array, of ingredients.
    for (int i = 0; i < size; i++)
    {
        list[i].update_amount(0);
        list[i].update_name("");
        list[i].update_measure("");
    }
    steps=""; //this is a string that indicates how to make the recipe.
    name=""; //this is the name of the recipe
}
//Recipe::Recipe(string steps, string name) :steps(steps), name(name) {}
void Recipe::grow()
{
    Ingredient* temp = list;//get a copy of the pointer
    list = new Ingredient[size * 2];//make a new larger array
    for (int i = 0; i < size; i++)
         list[i] = temp[i]; //copy from the full array into the new array
    delete[] temp; //delete the old array via temp
    size = size * 2;//double the size the as: size = size *2;
    temp = nullptr;
}

void Recipe::cover_up(int location) 
{
    for (int i = location; i < count-1; i++)
        list[i] = list[i + 1];
}
void Recipe::make_hole(int location) 
{ 
    for (int i = count; i >=location; i--)
       list[i]= list[i-1] ; 
}
bool Recipe::add_ingredient(Ingredient i, int location) 
{ 
    if (location>=0)
    {
        if (location == size - 1) grow();
        if (list[location].get_amount()!=0) make_hole(location);
        list[location] = i; 
        count++;
        return true;
    }
    else return false;
}
//This will try to add the Ingredient into the list at the given index location.
//The index needs to be valid.If it is valid, 
//then the ingredient is added.If it is not valid, 
//then the ingredient is not added.If the ingredient is added, 
//then the count is incremented.If the location is not the end of the list, 
//then the ingredients at the location and above are all shifted up 1 index to make a spot 
//for the new ingredient.If the ingredient is added, the count is incremented.


Ingredient Recipe::remove_ingredient(int location) 
{ 
    if (location <= count && location >= 0&&list[location].get_amount()!=0)
    {   
        cout << "removed";
        Ingredient d = list[location];
        cover_up(location);
        count--;
        return d;
    }
    else
        return Ingredient(); 
}
//This will attempt to remove the ingredient at the given location 
//if the location is valid.If the location is valid, 
//then all of the ingredients at a higher index location will be moved down to cover up 
//the removed ingredient.If the ingredient is removed the count of ingredients will be decremented.


void Recipe::update_steps(string new_steps) { steps = new_steps; }
void Recipe::update_name(string new_name) { name = new_name; }
string Recipe::get_steps() const { return steps; }
Ingredient Recipe::get_ingredient(int location) const
{ 
    if (location <= count && location >= 0) return list[location];
    else return Ingredient();
}
int Recipe::get_ingredient_count() const { return count; }
string Recipe::get_name() const { return name; }

void Recipe::show_recipe(std::ostream& out) const 
{ 
    out << "Name: " << name << endl;
    for (int i = 0; i < count; i++) 
    { 
        Ingredient p = list[i]; 
        p.display(out);
        out << endl;
        /*out << p.get_amount()<< "\t" << p.get_measure()
            << "\t" << p.get_name() << endl;  */
    }
    out << "####\n\nSteps:\n"<<steps;
    delete[] list;
}

