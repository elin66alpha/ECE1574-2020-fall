#include "Ingredient.h"

Ingredient::Ingredient()
{
    name ="";
    amount=0.0;
    measure="" ;
}
//Ingredient::Ingredient(string name, double amount, string measure) :name(name), amount(amount), measure(measure) {}
void Ingredient::update_name(string new_name){ name = new_name; }
void Ingredient::update_amount(double new_amount) { amount = new_amount; }
void Ingredient::update_measure(string new_measure) { measure = new_measure; }
string Ingredient::get_name() const { return name; }
double Ingredient::get_amount() const { return amount; }
string Ingredient::get_measure() const { return measure; }
void Ingredient::display(std::ostream& out) const {  out << amount << "\t" << measure << "\t" << name ;}