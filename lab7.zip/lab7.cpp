#include "lab7.h"
#include <iostream>
#include<string>
#include <fstream> // For ifstream
using namespace std;


void fromSeconds(int time, int& minutes, int& seconds) {

	minutes = time / 60;

	seconds = time % 60;

}

int toSeconds(int hours, int minutes, int seconds) {

	return hours * 60 * 60 + minutes * 60 + seconds;

}

double toCelsius(double degrees) {

	const double CTOF = 5.0 / 9.0;

	return (degrees - 32) * CTOF;

}

double toFahrenheit(double degress) {

	const double FTOC = 9.0 / 5.0;

	return degress * FTOC + 32;

}

double toInches(double centimeters) {

	const double CTOI = 2.54;

	return centimeters / CTOI;

}

double toCentimeters(double inches) {

	const double CTOI = 2.54;

	return inches * CTOI;

}

double toMiles(double kilometers) {

	const double KTOM = 1.609344;

	return kilometers / KTOM;

}

double toKilometers(double miles) {

	const double KTOM = 1.609344;

	return miles * KTOM;

}

int compare(string one, string two) {

	int i = 0;

	while (one[i] != '\0') {

		if (two[i] != '\0' && one[i] != two[i]) {

			break;

		}

		i++;

	}

	if (one[i] == '\0')

		return 0;

	else

		return 1;

}




void conversions(string input, string output) {

	
	string inpu = "COMMAND TO GET IN THIS STRING", temp = "GET NUM IN THIS STRING";

	ifstream file;

	file.open(input);

	string line;

	ofstream fout(output);


	int i, j, hrs, min, sec;

	double result;

	getline(file, line);

	while (line.length() > 0) {

		i = 0;

		j = 0;

		//extract command

		while (line[i] != ' ') {

			inpu[j] = line[i];

			j++;

			i++;

		}

		inpu[j] = '\0';

		if (compare("to-seconds", inpu) == 0) {

			j = 0;

			i++;

			while (line[i] != ':') {

				temp[j] = line[i];

				j++;

				i++;

			}

			temp[j] = '\0';

			hrs = stoi(temp);

			j = 0;

			i++;

			while (line[i] != ':') {

				temp[j] = line[i];

				j++;

				i++;

			}

			temp[j] = '\0';

			min = stoi(temp);

			j = 0;

			i++;

			while (line[i] != '\0') {

				temp[j] = line[i];

				j++;

				i++;

			}

			temp[j] = '\0';

			sec = stoi(temp);

			cout << "Command: " << "to-seconds " << hrs <<" "<<min<<" "<<sec<<" " << toSeconds(hrs, min, sec) << endl;
			fout << "Command: " << "to-seconds " << hrs << " " << min << " " << sec << " " << toSeconds(hrs, min, sec) << endl;

		}

		else if (compare("from-seconds", inpu) == 0) {

			j = 0;

			i++;

			while (line[i] != '\0') {

				temp[j] = line[i];

				j++;

				i++;

			}

			temp[j] = '\0';

			int time;

			time = stoi(temp);

			fromSeconds(time, min, sec);

			cout << "Command: " << line << " " << min << ":" << sec << endl;
			fout << "Command: " << line << " " << min << ":" << sec << endl;

		}

		else if (compare("to-Celsius", inpu) == 0) {

			j = 0;

			i++;

			while (line[i] != '\0') {

				temp[j] = line[i];

				j++;

				i++;

			}

			temp[j] = '\0';

			double far;

			far = stod(temp);

			cout << "Command: " << line << " " << toCelsius(far) << endl;
			fout << "Command: " << line << " " << toCelsius(far) << endl;

		}

		else if (compare("to-Fahrenheit", inpu) == 0) {

			j = 0;

			i++;

			while (line[i] != '\0') {

				temp[j] = line[i];

				j++;

				i++;

			}

			temp[j] = '\0';

			double far;

			far = stod(temp);

			cout << "Command: " << line << " " << toFahrenheit(far) << endl;
			fout << "Command: " << line << " " << toFahrenheit(far) << endl;

		}

		else if (compare("to-inches", inpu) == 0) {

			j = 0;

			i++;

			while (line[i] != '\0') {

				temp[j] = line[i];

				j++;

				i++;

			}

			temp[j] = '\0';

			double far;

			far = stod(temp);

			cout << "Command: " << line << " " << toInches(far) << endl;
			fout << "Command: " << line << " " << toInches(far) << endl;

		}

		else if (compare("to-centimeters", inpu) == 0) {

			j = 0;

			i++;

			while (line[i] != '\0') {

				temp[j] = line[i];

				j++;

				i++;

			}

			temp[j] = '\0';

			double far;

			far = stod(temp);

			cout << "Command: " << line << " " << toCentimeters(far) << endl;
			fout << "Command: " << line << " " << toCentimeters(far) << endl;

		}

		else if (compare("to-miles", inpu) == 0) {

			j = 0;

			i++;

			while (line[i] != '\0') {

				temp[j] = line[i];

				j++;

				i++;

			}

			temp[j] = '\0';

			double far;

			far = stod(temp);

			cout << "Command: " << line << " " << toMiles(far) << endl;
			fout << "Command: " << line << " " << toMiles(far) << endl;

		}

		else if (compare("to-kilometers", inpu) == 0) {

			j = 0;

			i++;

			while (line[i] != '\0') {

				temp[j] = line[i];

				j++;

				i++;

			}

			temp[j] = '\0';

			double far;

			far = stod(temp);

			cout << "Command: " << line << " " << toKilometers(far) << endl;
			fout << "Command: " << line << " " << toKilometers(far) << endl;

		}

		//clear line for next read

		line = "\0";

		getline(file, line);

	}
	fout.close();

}
	
