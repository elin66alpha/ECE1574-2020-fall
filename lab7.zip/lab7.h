#include <string>

void fromSeconds(int time, int& minutes, int& seconds);

int toSeconds(int hours, int minutes, int seconds);

double toCelsius(double degrees);

double toFahrenheit(double degress);

double toInches(double centimeters);

double toCentimeters(double inches);

double toMiles(double kilometers);

double toKilometers(double miles);

void conversions(std::string input, std::string output);