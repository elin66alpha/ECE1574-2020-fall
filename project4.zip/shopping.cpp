/*
*  Purpose for program
*  This program will allow a set of shopping list item to be read in and stored.  Then a command
*  file will allow a user to process the data for features by ids.
*
*  Programmer: Yilin.Liu
*  Date: Nov.20.2020
*
*  Honor Code: I have neither given nor received any unauthorized assistance with this program.
*/

#include "shopping.h"
void load(string filename,int& numline,int& size, widget*& data_array)
{
    int old = numline;
    string temp;
    ifstream load;
    load.open(filename);
    string lines; 
    while (getline(load, lines))
    {   
        if (lines.find('#')==-1) numline++;
        if (numline == size)
        {
            grow(data_array, size);
        }
    }
    load.close();
    ifstream loadagain;
    loadagain.open(filename);
    while (loadagain.peek() == '#')
        {
            loadagain.ignore(500, '\n');
        }
    for (int i = old; i < numline; i++)
    {
        loadagain >> data_array[i].id;
        loadagain >> data_array[i].description;
        loadagain >> temp;
        while (temp.find_first_of("0123456789"))
        {
           data_array[i].description.append(" "+temp);
           loadagain >> temp;
         }
        
        data_array[i].quantity = stoi(temp);
        loadagain >> temp;         
        temp = temp.substr(1, temp.length());
        data_array[i].cost=stod(temp);
     }
}
/*
*  Function: load
*  Purpose: This function will load a list text
*  input - file name, line count, array size and the array
*  output - array data recorded
*  commands - load
*/
void find(string& subcommand, ofstream& out,int& numline, widget*& data_array)
{
    bool temp=false;
    out << "Command: " << "find " << subcommand << endl;
    for (int i = 0; i < numline; i++) 
    {
        if (data_array[i].id == subcommand)
        {
            out << "\t" << data_array[i].id << "\t" << data_array[i].description
                << "\t" << data_array[i].quantity << "\t$" << fixed << setprecision(2) << data_array[i].cost
                << endl;
            temp = true;
        }
    } 
    if(temp==false) out << "\tSorry id " << subcommand << " not found." << endl;
}
/*
*  Function: find
*  Purpose: This function will find a id
*  input - file name, line count, array size and the array
*  output - finded id item
*  commands - find
*/
void add(ifstream& in,ofstream& out,int& numline, widget*& data_array)
{
   
    string temp;
        in >> data_array[numline].id;
        in >> data_array[numline].description;
        in >> temp;
        while (temp.find_first_of("0123456789"))
        {
            data_array[numline].description.append(" " + temp);
            in >> temp;
        }

        data_array[numline].quantity = stoi(temp);
        in >> temp;
        temp = temp.substr(1, temp.length());
        data_array[numline].cost=stod(temp);
        out << "Command: add    adding-->  " << data_array[numline].id << "\t" << data_array[numline].description
            << "\t" << data_array[numline].quantity << "\t$" << fixed << setprecision(2) << data_array[numline].cost << endl;
        out << "\tItem added.\n";
        numline++;
}
/*
*  Function: add
*  Purpose: This function will add the input to the array
*  input - file name,output file, line count, array size and the array
*  output - add an id to array
*  commands - add
*/
void remove(ifstream& in, ofstream& out, int&numline,widget*& data_array)
{
    string buffer; bool temp = false;
    in >> buffer; 
    out << "Command: remove " << buffer << endl;
    for (int i = 0; i < numline; i++)
    {
        if (data_array[i].id == buffer) 
        {
            out << "\t" << data_array[i].id << "\t" << data_array[i].description
                << "\t" << data_array[i].quantity << "\t$" << fixed << setprecision(2) << data_array[i].cost << endl;
            data_array[i].id = "";
            data_array[i].description = "";
            data_array[i].quantity = 0;
            data_array[i].cost = 0;
            temp = true;
        }
    }
    if(temp==false) out << "\tSorry id " << buffer << " not removed." << endl;
}
/*
*  Function: remove
*  Purpose: This function will remove the input to the array
*  input - file name,output file, line count, array size and the array
*  output - remove an id to array
*  commands - remove
*/
void total(int& numline,  ofstream& out,widget*& data_array)
{
    double value=0;
    for (int i = 0; i < numline; i++)
    {   
        if(data_array[i].cost>0)
        value = value + data_array[i].cost;
    }
    out << "Command: total" << endl;
    out << "\tTotal: $" << fixed << setprecision(2)<< value << endl;
}
/*
*  Function:total
*  Purpose: This function will calculate the total cost
*  input - file name,output file, line count, array size and the array
*  output - total cost
*  commands - total
*/
void save(ifstream& in, ofstream& out,int&size, widget*& data_array)
{
    string filename;
    in >> filename;
    out << "Command: save " << filename << endl;
    ofstream fout;
    fout.open(filename);
    for (int i = 0; i < size; i++)
    {
        if (data_array[i].id != "")
        {
            fout << data_array[i].id << "\t" << data_array[i].description << "\t"
                << data_array[i].quantity << "\t$" << fixed << setprecision(2) << data_array[i].cost << endl;
        }
    }
    fout.close();
}
/*
*  Function: save
*  Purpose: This function will save the stuff in array to another file
*  input - file name,output file, line count, array size and the array
*  output - file
*  commands - save
*/
void grow(widget*& array, int& size) 
{
    widget* temp = array;//get a copy of the pointer
    array = new widget[size*2];//make a new larger array
    for( int i=0; i<size; i++ )
        array[i] = temp[i]; //copy from the full array into the new array
    delete [] temp; //delete the old array via temp
    size =size*2;//double the size the as: size = size *2;
    temp = nullptr;
}
/*
*  Function: grow
*  Purpose: This function will grow the array bigger by 2 times
*  input - array and size
*  output - none
*  commands - grow
*/
void shopping_list( string input, string output )
{
    ifstream in;
    in.open(input);
    ofstream out;
    out.open(output);         
    int numline=0,size=10;string subcommand;
    widget* data_array = new widget[size];
    for (int i = 0; i < size; i++)
    {
        data_array[i].id = "";
        data_array[i].description = "";
        data_array[i].quantity = 0;
        data_array[i].cost = 0;
    }
    while(!in.fail())
    {
        string filename,command;
        in >> command;
        if(command =="load")
        {
            in >> filename;
            load(filename,numline,size,data_array);
            out << "Command: " << command << " " << filename << endl;
            out << "\tLoaded: " << numline << endl;
        }
        else if(command=="find")
        {    
            in >> subcommand;
            find(subcommand, out, numline, data_array);
        }
        else if (command == "add")
        {
            add(in,out,numline,data_array);
        }
        else if (command == "remove")
        {
            remove(in,out,numline,data_array);
        }
        else if (command == "total")
        {
            total(numline, out,data_array);
        }
        else if (command == "save")
        {
            save(in, out, size,data_array);
        }
    }
    
    delete[] data_array;
}
/*
*  Function: shopping_list
*  Purpose: This function is the main, input and slection
*  input - input file,output file
*  output - none
*  commands - none
*/