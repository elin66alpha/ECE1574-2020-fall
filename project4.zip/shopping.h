#include <iostream>
#include<istream>
#include<fstream>
#include<string>
#include <iomanip> 
using namespace std;
struct widget
{
	string id;
	string	description;
	int quantity;
	double cost;
};

void shopping_list( string input, string output );
void save(ifstream& in, ofstream& out, int& size, widget*& data_array);
void load(string filename, int& numline, int& size, widget*& data_array);
void find(string& subcommand, ofstream& out, int& numline, widget*& data_array);
void add(ifstream& in, ofstream& out, int& numline, widget*& data_array);
void remove(ifstream& in, ofstream& out, int& numline,widget*& data_array);
void total(int& numline, ofstream& out, widget*& data_array);
void grow(widget*& array, int& size);