// File Name: lab6.cpp
#include <iostream>
#include <cmath>
#include "lab6.h";
using namespace std;

// Function to return sum of the squares of the given parameters
double sumOfSquares(double d1, double d2, double d3, double d4)
{
	double sum;
	// Calculates the sum of the square of the given parameters
	sum = (d1 * d1) + (d2 * d2) + (d3 * d3) + (d4 * d4);
	// Return sum
	return sum;
}// End of function

// Function to return mean of the given parameters
double mean(int x1, int x2, int x3, int x4)
{
	double mean, sum = 0.0;
	// Calculates the sum
	sum = x1 + x2 + x3 + x4;
	// Calculates mean
	mean = sum / 4;
	// Return mean
	return mean;
}// End of function

// Function to return variance of the given parameters
double variance(int x1, int x2, int x3, int x4)
{
	// Calls the function to calculate mean
	double me = mean(x1, x2, x3, x4);
	double temp = 0;
	// Calls the function to calculate sum of the square of number minus mean
	temp += sumOfSquares((x1 - me), (x2 - me), (x3 - me), (x4 - me));
	// Return variance
	return temp / 4;
}// End of function

// Function to return standard deviation of the given parameters
double stdDev(int x1, int x2, int x3, int x4)
{
	// Calls the function to calculate variance and return standard deviation
	return sqrt(variance(x1, x2, x3, x4));
}// End of function

// main function definition
int main()
{
	int x1 = 1, x2 = 2, x3 = 3, x4 = 4;
	cout << "\n Mean: " << mean(x1, x2, x3, x4);
	cout << "\n Sum of squares: " << sumOfSquares(x1, x2, x3, x4);
	cout << "\n Variance: " << variance(x1, x2, x3, x4);
	cout << "\n standard deviation: " << stdDev(x1, x2, x3, x4);
}// End of main function