#ifndef VECTOR_H
#define VECTOR_H

#include <cstdlib>

//this is how we will allow for different types of data to be stored
typedef int storageType;

class Vector
{
private:
    static const int size = 10; //this is how large is the array
    int count;//this is how many items are in the array
    storageType storage[size];//this is the array
public:
    Vector();
    storageType itemAt(int location) const;
    void add(storageType data);

    int itemCount() const;

};

#endif
