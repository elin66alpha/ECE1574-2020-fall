#include "Vector.h"

Vector::Vector()
{
	count = 0;
	static const int size = 10;
	for (int i = 0; i < size; i++)
		storage[i] = 0;
}
storageType Vector::itemAt(int location) const
{
	if (location >= 0 && location < count)
	{
		return storage[location];
	}
	else return storageType();
}
void Vector::add(storageType data)
{
		if (count >= 10) count = 10;
		else {
			storage[count] = data;
			count++;
		}
		
}
int Vector::itemCount() const
{
	return count;
}