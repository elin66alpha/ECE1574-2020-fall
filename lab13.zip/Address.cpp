#include "Address.h"

Address::Address()
{
    string firstName;
    string lastName;
    string address;
}
Address::Address(string firstName, string lastName, string address) : firstName(firstName), lastName(lastName), address(address) {}
void Address::setFirstName(string newFirstName) { firstName = newFirstName; }
void Address::setLastName(string newLastName) {  lastName = newLastName; }
void Address::setAddress(string newAddress) {  address = newAddress; }
string Address::getFirstName() { return firstName; }
string Address::getLastName() { return lastName; }
string Address::getAddress() { return address; }