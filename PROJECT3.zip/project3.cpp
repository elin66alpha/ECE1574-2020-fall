#include "mapWalk.h"

void mapWalk(string input, string output)
{
	int number_array[50][50];
	int col_count=0, row_count=0,totalnum=0,row=0,col=0,startnum=0;
	char map_array[15][20];
	int steps=0;
	ifstream fin;
	fin.open(input);
	ofstream fout(output);
	for (int i = 0; i < 15; i++)
	{
		for (int j = 0; j < 20; j++)
			number_array[i][j] = 0;
	}//initialize
	while (!fin.fail())
	{
		string command, file;
		fin >> command;
		if (command=="File:")
		{
			string temp;
			fin >> file;
			fout << "Loading: " << file << endl;
			ifstream load;
			load.open(file);
			if (load.fail()) break;
			for (int k = 0; k < 5; k++)
			{
				string trash;
				getline(load, trash);
			}
			while (getline(load, temp))
			{
				row_count++;
				for (int i = 0; i < temp.length(); ++i)
				{
					if (temp.at(i) == ' ')
						totalnum++;
				}
			}
			col_count = totalnum / row_count;
			load.close();
			ifstream load2;
			load2.open(file);
			for (int k = 0; k < 5; k++)
			{
				string trash;
				getline(load2, trash);
			}
			for (int i = 0; i <row_count; i++)
			{
				for (int j = 0; j < col_count; j++)
				{
					load2 >> number_array[i][j];
				}
			}
			if (row_count >= 15) row_count = 15;
			if (col_count >= 20) col_count = 20;
			fout << "Number of rows: " << row_count << endl;
			fout << "Number of columns: " << col_count << endl;
			for (int t = 0; t < col_count; t++) fout << t << "\t";
			fout << "\n";
			for (int i = 0; i < row_count; i++)
			{
				fout << i << "\t";
				for (int j = 0; j < col_count; j++)
				{
					fout << number_array[i][j] << "\t";
				}
				fout << "\n"; 
			}
			load2.close();
		}
		if (command == "Greatest")
		{
			steps = 0;
			string command2;
			fin >> command2;
			int  col = 0;
			for (int i = 0; i < row_count; i++)
			{
				for (int j = 0; j < col_count; j++)
				{
					map_array[i][j] = '-';
				}
			}
			if (command2 == "Inclination")
			{
				fin >> startnum;
				row = startnum;
				fout << "Command: Greatest Inclination" << endl;
				if (row < row_count && row >= 0)
				{
					string laststep;
					while (col != col_count-1) 
				{
					int right = 0, down_right = 0, up_right = 0, up = 0, down = 0, left = 0, up_left = 0, down_left = 0;
					right = -number_array[row][col] + number_array[row][col + 1];
					up = -number_array[row][col] + number_array[row - 1][col];
					up_right = -number_array[row][col] + number_array[row - 1][col + 1];
					down = -number_array[row][col] + number_array[row + 1][col];
					down_right = -number_array[row][col] + number_array[row + 1][col + 1];
					left = -number_array[row][col] + number_array[row][col - 1];
					up_left = -number_array[row][col] + number_array[row - 1][col - 1];
					down_left = -number_array[row][col] + number_array[row + 1][col - 1];
					if (row - 1 == -1)
					{
						up = -5000;
						up_right = -5000;
						up_left=-5000;
					}
					
					if (row == row_count-1)
					{
						down = -5000;
						down_right = -5000;
						down_left = -5000;
					}
					if (col - 1 == -1)
					{
						left = -5000;
						up_left = -5000;
						down_left = -5000;
					}
	
					if (up >= right && up >= down && up >= down_right && up >= up_right)
					{
						if (laststep != "down")
						{
							map_array[row][col] = '^';
							row = row - 1;
							steps++;
							laststep = "up";
						}
						else
						{
							if (down_right >= up_right && down_right >= right && down_right >= down)
							{
								map_array[row][col] = '\\';
								col = col + 1;
								row = row + 1;
								steps++;
								laststep = "down_right";
							}
							else if (right >= up_right && right >= down_right && right >= down)
							{
								map_array[row][col] = '>';
								col = col + 1;
								steps++;
								laststep = "right";
							}
							else if (up_right >= right && up_right >= down_right && up_right >= down)
							{
								map_array[row][col] = '/';
								row = row - 1;
								col = col + 1;
								steps++;
								laststep = "up_right";
							}
							else if (down >= right && down >= down_right && down >= up_right)
							{
								map_array[row][col] = 'v';
								row = row + 1;
								steps++;
								laststep = "down";
							}
						}
					}
					else if (  up_right >= right && up_right >= down && up_right >= down_right &&  up_right >= up)
					{
						map_array[row][col] = '//';
						row = row-1;
						col = col+1;
						steps++;
						laststep = "up_right";
					}
					else if ( right >= up_right &&  right >= down && right >= down_right  && right >= up)
					{
						map_array[row][col] = '>';
						col = col+1;
						steps++;
						laststep = "right";
					}
					else if ( down >= up_right &&   down >= down_right && down >= right && down >= up)
					{
						if (laststep != "up")
						{
							map_array[row][col] = 'v';
							row = row + 1;
							steps++;
							laststep = "down";
						}
						else
						{
							if (down_right >= up_right &&  down_right >= right && down_right >= up)
							{
								map_array[row][col] = '\\';
								col = col + 1;
								row = row + 1;
								steps++;
								laststep = "down_right";
							}
							else if (right >= up_right && right >= down_right && right >= up)
							{
								map_array[row][col] = '>';
								col = col + 1;
								steps++;
								laststep = "right";
							}
							else if (up_right >= right &&  up_right >= down_right && up_right >= up)
							{
								map_array[row][col] = '/';
								row = row - 1;
								col = col + 1;
								steps++;
								laststep = "up_right";
							}
							else if (up >= right &&  up >= down_right && up >= up_right)
							{
								map_array[row][col] = '^';
								row = row - 1;
								steps++;
								laststep = "up";
							}
						}
					}
					else if ( down_right >= up_right &&  down_right >= down  && down_right >= right && down_right >= up)
					{
						map_array[row][col] = '\\';
						col = col+1;
						row = row+1;
						steps++;
						laststep = "down_right";
					}
				}
				map_array[row][col] = 'X';
				double first_average = (number_array[row][col] - number_array[startnum][0]), second_average = steps;
				double average = first_average / second_average;
				fout << "\tHeight change:  " << number_array[row][col] - number_array[startnum][0] << endl;
				fout << "\tSteps:  " << steps << endl;
				fout << "\tAverage change: " <<  average << endl;
				fout << "\tStarting row: " << startnum << endl;
				fout << "Number of rows: " << row_count << endl;
				fout << "Number of columns: " << col_count << endl;
				fout << "\t";
				for (int t = 0; t < col_count; t++) fout << t << "\t";
				fout << "\n";
				for (int i = 0; i < row_count; i++)
				{
					fout << i << "\t";
					for (int j = 0; j < col_count; j++)
					{
						fout << map_array[i][j] << "\t";
					}
					fout << "\n";
				}

				}
				else fout << "Bad starting row: "<<row<<endl;
			}

			/// ////////////////////////////////

			else if (command2 == "Declination") 
			{
				fin >> startnum;
				row = startnum;
				fout << "Command: Greatest Declination" << endl;
				if (row < row_count && row >= 0)
				{
					string laststep;
					while (col != col_count - 1)
				{
					int right = 0, down_right = 0, up_right = 0, up = 0, down = 0, left = 0, up_left = 0, down_left = 0;
					right = number_array[row][col] - number_array[row][col + 1];
					up = number_array[row][col] - number_array[row - 1][col];
					up_right = number_array[row][col] - number_array[row - 1][col + 1];
					down = number_array[row][col] - number_array[row + 1][col];
					down_right = number_array[row][col] - number_array[row + 1][col + 1];
					left = number_array[row][col] - number_array[row][col - 1];
					up_left = number_array[row][col] - number_array[row - 1][col - 1];
					down_left = number_array[row][col] - number_array[row + 1][col - 1];
					if (row - 1 == -1)
					{
						up = -5000;
						up_right = -5000;
						up_left = -5000;
					}
					
					if (row == row_count-1)
					{
						down = -5000;
						down_right = -5000;
						down_left = -5000;
					}
					if (col - 1 == -1)
					{
						left = -5000;
						up_left = -5000;
						down_left = -5000;
					}

					if (up >= right && up >= down && up >= down_right && up >= up_right)
					{
						if (laststep != "down")
						{
							map_array[row][col] = '^';
							row = row - 1;
							steps++;
							laststep = "up";
						}
						else
						{
							if (down_right >= up_right && down_right >= right && down_right >= down)
							{
								map_array[row][col] = '\\';
								col = col + 1;
								row = row + 1;
								steps++;
								laststep = "down_right";
							}
							else if (right >= up_right && right >= down_right && right >= down)
							{
								map_array[row][col] = '>';
								col = col + 1;
								steps++;
								laststep = "right";
							}
							else if (up_right >= right && up_right >= down_right && up_right >= down)
							{
								map_array[row][col] = '/';
								row = row - 1;
								col = col + 1;
								steps++;
								laststep = "up_right";
							}
							else if (down >= right && down >= down_right && down >= up_right)
							{
								map_array[row][col] = 'v';
								row = row + 1;
								steps++;
								laststep = "down";
							}
						}
					}
					else if (up_right >= right && up_right >= down && up_right >= down_right && up_right >= up)
					{
						map_array[row][col] = '//';
						row = row - 1;
						col = col + 1;
						steps++;
						laststep = "up_right";
					}
					else if (right >= up_right && right >= down && right >= down_right && right >= up)
					{
						map_array[row][col] = '>';
						col = col + 1;
						steps++;
						laststep = "right";
					}
					else if (down >= up_right && down >= down_right && down >= right && down >= up)
					{
						if (laststep != "up")
						{
							map_array[row][col] = 'v';
							row = row + 1;
							steps++;
							laststep = "down";
						}
						else
						{
							if (down_right >= up_right && down_right >= right && down_right >= up)
							{
								map_array[row][col] = '\\';
								col = col + 1;
								row = row + 1;
								steps++;
								laststep = "down_right";
							}
							else if (right >= up_right && right >= down_right && right >= up)
							{
								map_array[row][col] = '>';
								col = col + 1;
								steps++;
								laststep = "right";
							}
							else if (up_right >= right && up_right >= down_right && up_right >= up)
							{
								map_array[row][col] = '/';
								row = row - 1;
								col = col + 1;
								steps++;
								laststep = "up_right";
							}
							else if (up >= right && up >= down_right && up >= up_right)
							{
								map_array[row][col] = '^';
								row = row - 1;
								steps++;
								laststep = "up";
							}
						}
					}
					else if (down_right >= up_right && down_right >= down && down_right >= right && down_right >= up)
					{
						map_array[row][col] = '\\';
						col = col + 1;
						row = row + 1;
						steps++;
						laststep = "down_right";
					}
				}
				map_array[row][col] = 'X';
				double first_average = (number_array[row][col] - number_array[startnum][0]), second_average = steps;
				double average = first_average / second_average;
				fout << "\tHeight change:  " << number_array[row][col] - number_array[startnum][0] << endl;
				fout << "\tSteps:  " << steps << endl;
				fout << "\tAverage change: " <<  average << endl;
				fout << "\tStarting row: " << startnum << endl;
				fout << "Number of rows: " << row_count << endl;
				fout << "Number of columns: " << col_count << endl;
				fout << "\t";
				for (int t = 0; t < col_count; t++) fout << t << "\t";
				fout << "\n";
				for (int i = 0; i < row_count; i++)
				{
					fout << i << "\t";
					for (int j = 0; j < col_count; j++)
					{
						fout << map_array[i][j] << "\t";
					}
					fout << "\n";
				}
				}
				else fout << "Bad starting row: " <<row<< endl;
				
			}
		}
		if(command=="Least")
		{
			row = 0; col = 0;
			steps = 0;
			string temp;
			int startnum;
			fin >> temp;
			for (int i = 0; i < row_count; i++)
			{
				for (int j = 0; j < col_count; j++)
				{
					map_array[i][j] = '-';
				}
			}
			if (temp == "Elevation")
			{
			fin >> startnum;
			row = startnum;
			fout << "Command: Least Elevation" << endl;
			if (row < row_count && row>=0) 
			{
				
				string laststep;
				while (col != col_count - 1)
				{
				int right = 0, down_right = 0, up_right = 0, up = 0, down = 0, left = 0, up_left = 0, down_left = 0;
				right = abs(-number_array[row][col] + number_array[row][col + 1]);
				up = abs(-number_array[row][col] + number_array[row - 1][col]);
				up_right = abs(-number_array[row][col] + number_array[row - 1][col + 1]);
				down = abs(-number_array[row][col] + number_array[row + 1][col]);
				down_right = abs(-number_array[row][col] + number_array[row + 1][col + 1]);
				left = abs(-number_array[row][col] + number_array[row][col - 1]);
				up_left = abs(-number_array[row][col] + number_array[row - 1][col - 1]);
				down_left = abs(-number_array[row][col] + number_array[row + 1][col - 1]);
				if (row - 1 == -1)
				{
					up = 5000;
					up_right = 5000;
					up_left = 5000;
				}
				if (row == row_count-1)
				{
					down = 5000;
					down_right = 5000;
					down_left = 5000;
				}
				if (col - 1 == -1)
				{
					left = 5000;
					up_left = 5000;
					down_left = 5000;
				}

				if (up <= right && up <= down && up <= down_right && up <= up_right)
				{
					if (laststep != "down")
					{
						map_array[row][col] = '^';
						row = row - 1;
						steps++;
						laststep = "up";
					}
					else
					{
						if (down_right <= up_right && down_right <= right && down_right <= down)
						{
							map_array[row][col] = '\\';
							col = col + 1;
							row = row + 1;
							steps++;
							laststep = "down_right";
							
						}
						else if (right <= up_right && right <= down_right && right <= down)
						{
							map_array[row][col] = '>';
							col = col + 1;
							steps++;
							laststep = "right";
						}
						else if (up_right <= right && up_right <= down_right && up_right <= down)
						{
							map_array[row][col] = '/';
							row = row - 1;
							col = col + 1;
							steps++;
							laststep = "up_right";
						}
						else if (down <= right && down <= down_right && down <= up_right)
						{
							map_array[row][col] = 'v';
							row = row + 1;
							steps++;
							laststep = "down";
						}
					}
				}
				else if (up_right <= right && up_right <= down && up_right <= down_right && up_right <= up)
				{
					map_array[row][col] = '//';
					row = row - 1;
					col = col + 1;
					steps++;
					laststep = "up_right";
				}
				else if (right <= up_right && right <= down && right <= down_right && right <= up)
				{
					map_array[row][col] = '>';
					col = col + 1;
					steps++;
					laststep = "right";
				}
				else if (down <= up_right && down <= down_right && down <= right && down <= up)
				{
					if (laststep != "up")
					{
						map_array[row][col] = 'v';
						row = row + 1;
						steps++;
						laststep = "down";
					}
					else
					{
						if (down_right <= up_right && down_right <= right && down_right <= up)
						{
							map_array[row][col] = '\\';
							col = col + 1;
							row = row + 1;
							steps++;
							laststep = "down_right";
						}
						else if (right <= up_right && right <= down_right && right <= up)
						{
							map_array[row][col] = '>';
							col = col + 1;
							steps++;
							laststep = "right";
						}
						else if (up_right <= right && up_right <= down_right && up_right <= up)
						{
							map_array[row][col] = '/';
							row = row - 1;
							col = col + 1;
							steps++;
							laststep = "up_right";
						}
						else if (up <= right && up <= down_right && up <= up_right)
						{
							map_array[row][col] = '^';
							row = row - 1;
							steps++;
							laststep = "up";
						}
					}
				}
				else if (down_right <= up_right && down_right <= down && down_right <= right && down_right <= up)
				{
					map_array[row][col] = '\\';
					col = col + 1;
					row = row + 1;
					steps++;
					laststep = "down_right";
				}
			}
			map_array[row][col] = 'X';
			double first_average = (number_array[row][col] - number_array[startnum][0]), second_average = steps;
			double average = first_average / second_average;
			fout << "\tHeight change:  " << number_array[row][col] - number_array[startnum][0] << endl;
			fout << "\tSteps:  " << steps << endl;
			fout << "\tAverage change: " <<  average << endl;
			fout << "\tStarting row: " << startnum << endl;
			fout << "Number of rows: " << row_count << endl;
			fout << "Number of columns: " << col_count << endl;
			fout << "\t";
			for (int t = 0; t < col_count; t++) fout << t << "\t";
			fout << "\n";
			for (int i = 0; i < row_count; i++)
			{
				fout << i << "\t";
				for (int j = 0; j < col_count; j++)
				{
					fout << map_array[i][j] << "\t";
				}
				fout << "\n";
			}
			}
			else fout << "Bad starting row: " <<row<< endl;
			}
			
		}
		
		
	}//read from file
	fout.close();
}
