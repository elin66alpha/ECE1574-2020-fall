#include <string>
#include <fstream>
#include <iomanip>
#include <istream>
#include <iostream>

using namespace std;
using std::string;

void mapWalk(string input, string output);